import { useStorageState } from '@/hooks/useStorageState';
import { api } from '@/lib/axiosInstance';
import { useFocusEffect } from 'expo-router';
import { useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';

export default function Tab() {
  const theme = useColorScheme();
  const [[isLoading, session]] = useStorageState('session');

  useFocusEffect(
    useCallback(() => {
      if (isLoading || !session?.token) {
        console.log('⚠️ 세션이 아직 준비되지 않아서 요청 생략');
        return;
      }
  
      (async function fetchPTList() {
        try {
          const response = await api.get('/api/PT/mypt');
          console.log('✅ PT 데이터:', response.data);
        } catch (e: any) {
          console.log('🚨 요청에 사용된 Authorization:', e?.config?.headers?.Authorization);
          console.log('🚨 상태코드:', e?.response?.status);
          console.log('🚨 전체 응답:', e?.response);
        }
      })();
    }, [isLoading, session])
  );

  return (
    <View
      style={theme === 'dark' ? styles.darkContainer : styles.lightContainer}
    >
      {/* <StatusBar style="light" /> */}
      <Text>personal training</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  darkContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#121212',
  },
  lightContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
});
