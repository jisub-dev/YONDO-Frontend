// src/lib/axiosInterceptor.ts
import { useEffect } from 'react';
import { useAuth } from '@/api/auth';
import { useStorageState } from '@/hooks/useStorageState';
import { api } from './axiosInstance';

let isRefreshing = false;
let failedQueue: any[] = [];

const processQueue = (error: any, token: string | null = null) => {
  console.log('📦 processQueue:', {
    error,
    tokenPreview: token?.slice?.(0, 20) || null,
    queueLength: failedQueue.length,
  });

  failedQueue.forEach(prom => {
    if (token) prom.resolve(token);
    else prom.reject(error);
  });

  failedQueue = [];
};

/// 인터셉터는 axios요청시 특정 조건에 따라 요청을 가로채는 기능을 제공한다.
/// 이를 통해 요청에 대한 헤더를 추가하거나, 요청을 중단시킬 수 있다.
/// 이 파일은 axios 인터셉터를 사용하여 토큰 갱신을 구현한 예시이다.
/// 토큰이 만료되었을 때, 401 Unauthorized 에러를 받으면 토큰을 갱신하고 다시 요청을 보내는 방식이다.
/// 이 파일은 useAxiosInterceptor라는 커스텀 훅을 제공한다.
/// 이 훅은 세션 정보를 받아 토큰을 요청 헤더에 추가하고, 토큰 갱신이 필요할 때 자동으로 처리한다.
/// 이 훅을 사용하면 토큰 갱신이 필요한 요청에 대해 따로 처리할 필요가 없다.
/// 이 파일은 세션 정보를 받아 토큰을 요청 헤더에 추가하고, 토큰 갱신이 필요할 때 자동으로 처리한다.
export const useAxiosInterceptor = () => {
  const [[isLoading, session], setSession] = useStorageState('session');
  const { logoutUser } = useAuth();

  useEffect(() => {
    console.log('--- 인터셉터 useEffect 실행 ---');

    // ✅ 세션이 완전히 로딩되기 전에는 인터셉터 등록하지 않음
    if (isLoading || !session) {
      console.log('* 세션 로딩 중이거나 없음 → 인터셉터 등록 생략');
      return;
    }
    console.log('* 인터셉터 등록됨 / session.token:', session.token);

    console.log('✅ Axios 인터셉터 등록됨');

    const requestInterceptor = api.interceptors.request.use(config => {
      console.log('📡 [Axios Request 인터셉터]');
      console.log('📎 요청 URL:', config.url);
      console.log('📎 요청 메서드:', config.method?.toUpperCase());
      console.log('📎 요청 헤더:', config.headers);
      console.log('* 인터셉터에서 세션 토큰 확인:', session.token);
    
      if (session?.token) {
        config.headers.Authorization = `Bearer ${session.token}`;
        console.log('✅ Authorization 헤더 추가됨:', config.headers.Authorization);
      } else {
        console.warn('⚠️ 세션 토큰이 없어 Authorization 헤더 미포함');
      }
    
      return config;
    });

    const responseInterceptor = api.interceptors.response.use(
      res => res,
      async err => {
        /// 요청 오류가 401 Unauthorized이고, 토큰 갱신이 필요한 경우 처리함
        const originalRequest = err.config;

        if (err.response?.status === 401 && !originalRequest._retry) {
          console.warn('🔐 401 Unauthorized → 토큰 갱신 시도 중...');
          originalRequest._retry = true;

          if (isRefreshing) {
            console.log('🕒 이미 갱신 중 → 요청 큐에 등록');
            return new Promise((resolve, reject) => {
              failedQueue.push({ resolve, reject });
            })
              .then((token: unknown) => {
                console.log('🟢 새 토큰으로 요청 재시도');
                originalRequest.headers.Authorization = `Bearer ${token}`;
                return api(originalRequest);
              })
              .catch(error => Promise.reject(error));
          }

          isRefreshing = true;

          try {
            const identifier = session.user?.identifier;
            const refreshToken = session?.RT;
          
            console.log('🧪 identifier:', identifier, typeof identifier);
            console.log('🧪 refreshToken:', refreshToken, typeof refreshToken);
          
            if (
              typeof identifier !== 'string' ||
              !identifier.trim() ||
              typeof refreshToken !== 'string' ||
              !refreshToken.trim()
            ) {
              console.error('❌ 세션 정보 부족 → 토큰 갱신 불가');
              console.log('⚠️ session:', JSON.stringify(session, null, 2));
              throw new Error('세션 정보 누락');
            }
            console.log(`🔄 토큰 갱신 요청: /api/tokens/refresh`);
            const res = await api.post(`/api/tokens/refresh`, { RT: refreshToken });

            const newToken = res.data.token;
            const newRT = res.data.RT;

            console.log('✅ 토큰 갱신 성공');
            console.log('🆕 AccessToken:', newToken.slice(0, 20) + '...');
            console.log('🆕 RefreshToken:', newRT.slice(0, 20) + '...');

            await setSession({
              token: newToken,
              RT: newRT,
              user: session.user,
            });
  
            originalRequest.headers.Authorization = `Bearer ${newToken}`;
            processQueue(null, newToken);
            return api(originalRequest);
          } catch (refreshError: any) {
            const code = refreshError?.response?.data?.code;
            console.error('❌ 토큰 갱신 실패:', refreshError?.response?.data);

            if (code === 'T002') {
              console.warn('🔒 RefreshToken 만료 → 로그아웃 실행');
              logoutUser(session.user?.identifier);
            }

            processQueue(refreshError, null);
            return Promise.reject(refreshError);
          } finally {
            isRefreshing = false;
          }
        }

        return Promise.reject(err);
      }
    );

    return () => {
      console.log('🧹 Axios 인터셉터 해제됨');
      api.interceptors.request.eject(requestInterceptor);
      api.interceptors.response.eject(responseInterceptor);
    };
  }, [isLoading, JSON.stringify(session)]); // ✅ isLoading도 의존성에 추가
};