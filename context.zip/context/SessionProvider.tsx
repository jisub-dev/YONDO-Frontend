import React from 'react';
import { createContext, useContext } from 'react';
import { useStorageState } from '../hooks/useStorageState';
import { BirthType, BranchType, CareerType, GenderType, IdentifierType, NameType, NTRPType, ReceiptInfoType, ReceiptNumberType, ReceiptTypeType, RefundAccountType, RefundBankType, RoleType, TrainerIdType } from '@/screen/RegisterScreen';

export type userType = {
  identifier: IdentifierType,
  name: NameType,
  gender: GenderType,
  phone: string,
  branch: BranchType,
  birth: string,
  ntrp: NTRPType,
  career: CareerType,
  refundAccount: RefundAccountType,
  refundBank: RefundBankType,
  receiptInfo: ReceiptInfoType,
  receiptType: ReceiptTypeType,
  receiptNumber: ReceiptNumberType,
  trainerId: TrainerIdType,
  banned: boolean,
  createdAt: string,
  role: RoleType
}

type SessionType = {
  token: string | null;
  RT: string | null;
  user: userType | null;
};


const AuthContext = createContext({
  signIn: (session: SessionType) => {},
  signOut: () => {},
  session: {
    token: null,
    RT: null,
    user: null,
  } as SessionType | null,
  isLoading: true,
});

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [[isLoading, session], setSession] = useStorageState('session');

  // const signIn = ({token, RT}: SignInParamsType) => (
  //   setSession({token, RT})
  // )

  return (
    <AuthContext.Provider
      value={{
        signIn: async (session: SessionType) => {
          try {
            console.log('✅ SignIn 함수 호출 완료');
            await setSession(session);
          } catch (err) {
            console.error('❌ 세션 저장 실패 (signIn):', err);
            throw err; // 진짜로 실패한 경우엔 다시 던질 수도 있음
          }
        },
        signOut: () => setSession(null),
        session,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useSession() {
  return useContext(AuthContext);
}
